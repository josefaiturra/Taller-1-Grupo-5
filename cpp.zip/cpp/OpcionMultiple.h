#ifndef OPCIONMULTIPLE_H
#define OPCIONMULTIPLE_H

#include "Pregunta.h"

class OpcionMultiple : public Pregunta {
private:
    string* opciones;
    int cantidadOpciones;
    int indiceCorrecto;

public:
    OpcionMultiple(string enunciado, string nivel, int tiempo, string* opciones, int cantidad, int correcta);
    ~OpcionMultiple();
    void mostrar() const override;
    string obtenerRespuestaCorrecta() const override;
};

#endif
