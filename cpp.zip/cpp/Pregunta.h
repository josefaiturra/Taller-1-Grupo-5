#ifndef PREGUNTA_H
#define PREGUNTA_H

#include <string>
using namespace std;

class Pregunta {
protected:
    string enunciado;
    string nivelTaxonomico;
    int tiempoEstimado;

public:
    Pregunta(string enunciado, string nivel, int tiempo);
    virtual ~Pregunta();
    virtual void mostrar() const = 0;
    virtual string obtenerRespuestaCorrecta() const = 0;
    string getNivel() const;
    int getTiempo() const;
};

#endif
