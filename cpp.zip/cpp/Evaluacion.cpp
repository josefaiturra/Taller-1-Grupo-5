#include "Evaluacion.h"
#include <iostream>
using namespace std;

Evaluacion::Evaluacion(Pregunta** preguntas, int cantidad) : preguntas(preguntas), cantidad(cantidad) {}

Evaluacion::~Evaluacion() {
    delete[] preguntas;
}

void Evaluacion::mostrarEvaluacion() const {
    for (int i = 0; i < cantidad; ++i) {
        preguntas[i]->mostrar();
    }
}

int Evaluacion::calcularTiempoTotal() const {
    int tiempoTotal = 0;
    for (int i = 0; i < cantidad; ++i) {
        tiempoTotal += preguntas[i]->getTiempo();
    }
    return tiempoTotal;
}
