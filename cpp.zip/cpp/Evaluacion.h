#ifndef EVALUACION_H
#define EVALUACION_H

#include "Pregunta.h"

class Evaluacion {
private:
    Pregunta** preguntas;
    int cantidad;

public:
    Evaluacion(Pregunta** preguntas, int cantidad);
    ~Evaluacion();
    void mostrarEvaluacion() const;
    int calcularTiempoTotal() const;
};

#endif
