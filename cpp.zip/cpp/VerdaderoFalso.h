#ifndef VERDADEROFALSO_H
#define VERDADEROFALSO_H

#include "Pregunta.h"

class VerdaderoFalso : public Pregunta {
private:
    bool respuestaCorrecta;

public:
    VerdaderoFalso(string enunciado, string nivel, int tiempo, bool correcta);
    void mostrar() const override;
    string obtenerRespuestaCorrecta() const override;
};

#endif
