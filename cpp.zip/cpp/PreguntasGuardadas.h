#ifndef PREGUNTASGUARDADAS_H
#define PREGUNTASGUARDADAS_H

#include "Pregunta.h"

class PreguntasGuardadas {
private:
    Pregunta** preguntas;
    int cantidad;
    int capacidad;

    void redimensionar();

public:
    PreguntasGuardadas();
    ~PreguntasGuardadas();
    void agregarPregunta(Pregunta* p);
    void eliminarPregunta(int index);
    void actualizarPregunta(int index, Pregunta* nueva);
    void mostrarTodas() const;
    void buscarPorNivel(const string& nivel) const;
    Pregunta** generarEvaluacion(int cantidad, const string& nivel, int& totalGeneradas) const;
};

#endif
