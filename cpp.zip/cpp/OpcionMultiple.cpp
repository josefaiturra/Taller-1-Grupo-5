#include "OpcionMultiple.h"
#include <iostream>
using namespace std;

OpcionMultiple::OpcionMultiple(string enunciado, string nivel, int tiempo, string* opciones, int cantidad, int correcta)
    : Pregunta(enunciado, nivel, tiempo), cantidadOpciones(cantidad), indiceCorrecto(correcta) {
    this->opciones = new string[cantidadOpciones];
    for (int i = 0; i < cantidadOpciones; ++i) {
        this->opciones[i] = opciones[i];
    }
}

OpcionMultiple::~OpcionMultiple() {
    delete[] opciones;  // Aseguramos que la memoria se libere correctamente
}

void OpcionMultiple::mostrar() const {
    cout << "Pregunta: " << enunciado << endl;
    for (int i = 0; i < cantidadOpciones; ++i) {
        cout << i + 1 << ". " << opciones[i] << endl;
    }
    cout << "Nivel taxonomico: " << nivelTaxonomico << endl;
    cout << "Tiempo estimado: " << tiempoEstimado << " minutos" << endl;
}

string OpcionMultiple::obtenerRespuestaCorrecta() const {
    return opciones[indiceCorrecto];
}
