#include "VerdaderoFalso.h"
#include <iostream>
using namespace std;

VerdaderoFalso::VerdaderoFalso(string enunciado, string nivel, int tiempo, bool correcta)
    : Pregunta(enunciado, nivel, tiempo), respuestaCorrecta(correcta) {}

void VerdaderoFalso::mostrar() const {
    cout << "Pregunta: " << enunciado << " (V/F)" << endl;
    cout << "Nivel taxonomico: " << nivelTaxonomico << endl;
    cout << "Tiempo estimado: " << tiempoEstimado << " minutos" << endl;
}

string VerdaderoFalso::obtenerRespuestaCorrecta() const {
    return respuestaCorrecta ? "Verdadero" : "Falso";
}
