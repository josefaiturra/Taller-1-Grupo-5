#include "Pregunta.h"

// Constructor
Pregunta::Pregunta(string enunciado, string nivel, int tiempo)
    : enunciado(enunciado), nivelTaxonomico(nivel), tiempoEstimado(tiempo) {}

// Destructor
Pregunta::~Pregunta() {}

// Métodos concretos
string Pregunta::getNivel() const {
    return nivelTaxonomico;
}

int Pregunta::getTiempo() const {
    return tiempoEstimado;
}
