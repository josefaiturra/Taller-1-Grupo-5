#include <iostream>
#include "OpcionMultiple.h"
#include "VerdaderoFalso.h"
#include "PreguntasGuardadas.h"
#include "Evaluacion.h"
#include "Pregunta.h"


using namespace std;

void mostrarMenu() {
    cout << "\n///// MENU PRINCIPAL /////\n";
    cout << "1. Agregar pregunta\n";
    cout << "2. Eliminar pregunta\n";
    cout << "3. Actualizar pregunta\n";
    cout << "4. Mostrar todas las preguntas\n";
    cout << "5. Buscar por nivel taxonomico\n";
    cout << "6. Generar evaluacion\n";
    cout << "0. Salir\n";
    cout << "Ingrese una opcion: ";
}

int main() {
    PreguntasGuardadas preguntasGuardadas;
    int opcion = -1;

    while (opcion != 0) {
        mostrarMenu();
        cin >> opcion;

        if (opcion == 1) {
            int tipo;
            cout << "Tipo de pregunta:\n1. Opcion Multiple\n2. Verdadero/Falso\nOpcion: ";
            cin >> tipo;
            cin.ignore();

            string enunciado, nivel;
            int tiempo;

            cout << "Enunciado: ";
            getline(cin, enunciado);
            cout << "Nivel taxonomico: ";
            getline(cin, nivel);
            cout << "Tiempo estimado (minutos): ";
            cin >> tiempo;
            cin.ignore();

            if (tipo == 1) {
                string* opciones = new string[4];
                for (int i = 0; i < 4; ++i) {
                    cout << "Opcion " << i + 1 << ": ";
                    getline(cin, opciones[i]);
                }
                int correcta;
                cout << "Numero de la opcion correcta (1-4): ";
                cin >> correcta;
                cin.ignore();
                preguntasGuardadas.agregarPregunta(new OpcionMultiple(enunciado, nivel, tiempo, opciones, 4, correcta - 1));
                delete[] opciones;
            } else {
                bool respuesta;
                cout << "Respuesta (1 = Verdadero, 0 = Falso): ";
                cin >> respuesta;
                cin.ignore();
                preguntasGuardadas.agregarPregunta(new VerdaderoFalso(enunciado, nivel, tiempo, respuesta));
            }

            cout << "Pregunta agregada correctamente.\n";
        }

        else if (opcion == 2) {
            int index;
            preguntasGuardadas.mostrarTodas();
            cout << "Indice de la pregunta a eliminar: ";
            cin >> index;
            preguntasGuardadas.eliminarPregunta(index);
        }

        else if (opcion == 3) {
            int index;
            preguntasGuardadas.mostrarTodas();
            cout << "Indice de la pregunta a actualizar: ";
            cin >> index;
            cin.ignore();

            int tipo;
            cout << "Nuevo tipo:\n1. Opcion Multiple\n2. Verdadero/Falso\nOpcion: ";
            cin >> tipo;
            cin.ignore();

            string enunciado, nivel;
            int tiempo;

            cout << "Nuevo enunciado: ";
            getline(cin, enunciado);
            cout << "Nuevo nivel taxonomico: ";
            getline(cin, nivel);
            cout << "Nuevo tiempo estimado (minutos): ";
            cin >> tiempo;
            cin.ignore();

            if (tipo == 1) {
                string* opciones = new string[4];
                for (int i = 0; i < 4; ++i) {
                    cout << "Opcion " << i + 1 << ": ";
                    getline(cin, opciones[i]);
                }
                int correcta;
                cout << "Numero de la opcion correcta (1-4): ";
                cin >> correcta;
                cin.ignore();
                preguntasGuardadas.actualizarPregunta(index, new OpcionMultiple(enunciado, nivel, tiempo, opciones, 4, correcta - 1));
                delete[] opciones;
            } else {
                bool respuesta;
                cout << "Respuesta (1 = Verdadero, 0 = Falso): ";
                cin >> respuesta;
                cin.ignore();
                preguntasGuardadas.actualizarPregunta(index, new VerdaderoFalso(enunciado, nivel, tiempo, respuesta));
            }

            cout << "Pregunta actualizada correctamente.\n";
        }

        else if (opcion == 4) {
            preguntasGuardadas.mostrarTodas();
        }

        else if (opcion == 5) {
            string nivel;
            cout << "Nivel taxonomico a buscar: ";
            cin.ignore();
            getline(cin, nivel);
            preguntasGuardadas.buscarPorNivel(nivel);
        }

        else if (opcion == 6) {
            int cantidad;
            string nivel;
            cout << "Nivel taxonomico: ";
            cin.ignore();
            getline(cin, nivel);
            cout << "Cantidad de preguntas: ";
            cin >> cantidad;

            int totalGeneradas = 0;
            Pregunta** seleccionadas = preguntasGuardadas.generarEvaluacion(cantidad, nivel, totalGeneradas);

            if (totalGeneradas == 0) {
                cout << "No hay suficientes preguntas para generar una evaluacion.\n";
            } else {
                Evaluacion eval(seleccionadas, totalGeneradas);
                eval.mostrarEvaluacion();
                cout << "\nTiempo total estimado: " << eval.calcularTiempoTotal() << " minutos.\n";
                delete[] seleccionadas;
            }
        }

        else if (opcion == 0) {
            cout << "Saliendo del programa...\n";
        }

        else {
            cout << "Opcion no valida. Intente nuevamente.\n";
        }
    }

    return 0;
}
