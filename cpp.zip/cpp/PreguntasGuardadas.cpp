#include "PreguntasGuardadas.h"
#include <iostream>
using namespace std;

PreguntasGuardadas::PreguntasGuardadas() {
    capacidad = 10;
    cantidad = 0;
    preguntas = new Pregunta*[capacidad];
}

PreguntasGuardadas::~PreguntasGuardadas() {
    for (int i = 0; i < cantidad; ++i) {
        delete preguntas[i];
    }
    delete[] preguntas;
}

void PreguntasGuardadas::redimensionar() {
    capacidad *= 2;
    Pregunta** nuevo = new Pregunta*[capacidad];
    for (int i = 0; i < cantidad; ++i) {
        nuevo[i] = preguntas[i];
    }
    delete[] preguntas;
    preguntas = nuevo;
}

void PreguntasGuardadas::agregarPregunta(Pregunta* p) {
    if (cantidad == capacidad) {
        redimensionar();
    }
    preguntas[cantidad++] = p;
}

void PreguntasGuardadas::eliminarPregunta(int index) {
    if (index >= 0 && index < cantidad) {
        delete preguntas[index];
        for (int i = index; i < cantidad - 1; ++i) {
            preguntas[i] = preguntas[i + 1];
        }
        --cantidad;
        cout << "Pregunta eliminada correctamente.\n";
    } else {
        cout << "Indice invalido.\n";
    }
}

void PreguntasGuardadas::actualizarPregunta(int index, Pregunta* nueva) {
    if (index >= 0 && index < cantidad) {
        delete preguntas[index];
        preguntas[index] = nueva;
    } else {
        cout << "Indice invalido.\n";
    }
}

void PreguntasGuardadas::mostrarTodas() const {
    for (int i = 0; i < cantidad; ++i) {
        cout << "\nPregunta #" << i << ":\n";
        preguntas[i]->mostrar();
    }
}

void PreguntasGuardadas::buscarPorNivel(const string& nivel) const {
    for (int i = 0; i < cantidad; ++i) {
        if (preguntas[i]->getNivel() == nivel) {
            preguntas[i]->mostrar();
        }
    }
}

Pregunta** PreguntasGuardadas::generarEvaluacion(int cantidadSolicitada, const string& nivel, int& totalGeneradas) const {
    Pregunta** seleccionadas = new Pregunta*[cantidadSolicitada];
    totalGeneradas = 0;

    for (int i = 0; i < cantidad && totalGeneradas < cantidadSolicitada; ++i) {
        if (preguntas[i]->getNivel() == nivel) {
            seleccionadas[totalGeneradas++] = preguntas[i];
        }
    }

    return seleccionadas;
}
